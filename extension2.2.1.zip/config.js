// ClassPilot extension configuration
// This file is required by the service worker

globalThis.SENTRY_DSN_EXTENSION = "";
globalThis.SENTRY_ENV = "production";
globalThis.SENTRY_DEV_MODE = false;
// Server URL is set in service-worker.js DEFAULT_SERVER_URL
