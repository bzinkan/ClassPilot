declare module "googleapis" {
  export const google: any;
}
